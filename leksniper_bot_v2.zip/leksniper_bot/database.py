import aiosqlite
import json

DB_PATH = "bot_database.db"

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                user_name TEXT,
                item_id TEXT,
                item_name TEXT,
                status TEXT DEFAULT 'new',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS wholesale_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                request_text TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.commit()

async def add_order(user_id, user_name, item_id, item_name):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO orders (user_id, user_name, item_id, item_name) VALUES (?, ?, ?, ?)",
            (user_id, user_name, item_id, item_name)
        )
        await db.commit()

async def add_wholesale_request(user_id, request_text):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO wholesale_requests (user_id, request_text) VALUES (?, ?)",
            (user_id, request_text)
        )
        await db.commit()

async def get_all_orders():
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT * FROM orders ORDER BY created_at DESC LIMIT 10") as cursor:
            return await cursor.fetchall()
