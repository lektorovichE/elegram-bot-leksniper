import asyncio
import logging
import json
from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.client.default import DefaultBotProperties
from openai import AsyncOpenAI

import config
import database

# --- ЛОГИРОВАНИЕ ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- СОСТОЯНИЯ ---
class Order(StatesGroup):
    name = State()
    contact = State()
    ai_chat = State()
    wholesale = State()

# --- ЗАГРУЗКА КАТАЛОГА ---
with open("catalog.json", "r", encoding="utf-8") as f:
    CATALOG = json.load(f)

ALL_PRODUCTS = {}
for cat_code, cat_data in CATALOG.items():
    for subcat_code, subcat_data in cat_data["subcats"].items():
        for item in subcat_data["items"]:
            ALL_PRODUCTS[item["id"]] = {**item, "cat_code": cat_code, "subcat_code": subcat_code}

catalog_for_ai = {}
for cat_code, cat_data in CATALOG.items():
    catalog_for_ai[cat_data["name"]] = {}
    for subcat_code, subcat_data in cat_data["subcats"].items():
        catalog_for_ai[cat_data["name"]][subcat_data["name"]] = [f"{item['name']} - {item['price']}" for item in subcat_data["items"]]

# --- ИНИЦИАЛИЗАЦИЯ ---
bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
dp = Dispatcher()
client = AsyncOpenAI(api_key=config.OPENAI_API_KEY, base_url=config.OPENAI_BASE_URL)

# --- КЛАВИАТУРЫ ---
def get_main_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🛒 КАТАЛОГ")],
        [KeyboardButton(text="🤖 AI Ассистент")],
        [KeyboardButton(text="📦 Оптовый запрос / Гуманитарка")]
    ], resize_keyboard=True)

def get_cats_kb():
    buttons = [[InlineKeyboardButton(text=d["name"], callback_data=f"cat:{k}")] for k, d in CATALOG.items()]
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_subcats_kb(cat_code):
    cat_data = CATALOG[cat_code]
    buttons = [[InlineKeyboardButton(text=d["name"], callback_data=f"sub:{cat_code}:{k}")] for k, d in cat_data["subcats"].items()]
    buttons.append([InlineKeyboardButton(text="⬅️ Назад", callback_data="back:main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_items_kb(cat_code, subcat_code):
    subcat_data = CATALOG[cat_code]["subcats"][subcat_code]
    buttons = [[InlineKeyboardButton(text=f"{i['name']} | {i['price']}", callback_data=f"prod:{i['id']}")] for i in subcat_data["items"]]
    buttons.append([InlineKeyboardButton(text="⬅️ Назад", callback_data=f"back:cat:{cat_code}")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_prod_kb(pid):
    p = ALL_PRODUCTS[pid]
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 КУПИТЬ", callback_data=f"buy:{pid}")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"back:sub:{p['cat_code']}:{p['subcat_code']}")]
    ])

def get_ai_exit_kb():
    return ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ Выйти из чата")]], resize_keyboard=True)

# --- ОБРАБОТЧИКИ ---

@dp.message(CommandStart())
async def start(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("<b>LEKSNIPER - Спецснаряжение</b>\n\nПриветствую! Я помогу выбрать лучшее снаряжение для боевых задач.\n\nВыберите раздел:", reply_markup=get_main_kb())

@dp.message(F.text == "🛒 КАТАЛОГ")
async def show_cats(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("Выберите категорию:", reply_markup=get_cats_kb())

@dp.message(F.text == "🤖 AI Ассистент")
async def ai_start(message: types.Message, state: FSMContext):
    await state.set_state(Order.ai_chat)
    await message.answer("Я ваш AI-ассистент LEKSNIPER. Задайте любой вопрос по снаряжению или качеству. Я объясню, почему наше снаряжение лучше китайских аналогов.", reply_markup=get_ai_exit_kb())

@dp.message(F.text == "📦 Оптовый запрос / Гуманитарка")
async def wholesale_start(message: types.Message, state: FSMContext):
    await state.set_state(Order.wholesale)
    await message.answer("Для оптовых заказчиков и гуманитарных миссий у нас особые условия.\n\n<b>Пришлите список нужных товаров и цены, которые вам предложили другие — мы сделаем предложение выгоднее!</b>", reply_markup=get_ai_exit_kb())

@dp.message(F.text == "❌ Выйти из чата")
async def ai_exit(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("Возвращаюсь в главное меню.", reply_markup=get_main_kb())

@dp.message(Order.wholesale)
async def wholesale_handler(message: types.Message, state: FSMContext):
    if not message.text: return
    await database.add_wholesale_request(message.from_user.id, message.text)
    await bot.send_message(config.ADMIN_ID, f"🚨 <b>НОВЫЙ ОПТОВЫЙ ЗАПРОС!</b>\nОт: @{message.from_user.username}\nТекст: {message.text}")
    await message.answer("Ваш запрос принят! Мы изучим ваш список и свяжемся с вами в ближайшее время, чтобы предложить лучшие условия.", reply_markup=get_main_kb())
    await state.clear()

@dp.message(Order.ai_chat)
async def ai_handler(message: types.Message, state: FSMContext):
    if not message.text: return
    await bot.send_chat_action(message.chat.id, "typing")
    try:
        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": config.SYSTEM_PROMPT + f"\n\nКАТАЛОГ ТОВАРОВ:\n{json.dumps(catalog_for_ai, ensure_ascii=False)}"},
                {"role": "user", "content": message.text}
            ]
        )
        ai_text = response.choices[0].message.content
        if "ОФОРМИТЬ ЗАКАЗ:" in ai_text:
            pid = ai_text.split("ОФОРМИТЬ ЗАКАЗ:")[1].strip().strip("[]")
            if pid in ALL_PRODUCTS:
                await state.update_data(pid=pid)
                await message.answer(ai_text.split("ОФОРМИТЬ ЗАКАЗ:")[0].strip())
                await message.answer(f"Оформляем заказ на <b>{ALL_PRODUCTS[pid]['name']}</b>.\nВведите ваше ФИО:", reply_markup=types.ReplyKeyboardRemove())
                await state.set_state(Order.name)
                return
        await message.answer(ai_text)
    except Exception as e:
        logger.error(f"AI Error: {e}")
        await message.answer("Извините, произошла ошибка. Попробуйте позже.")

# --- ОФОРМЛЕНИЕ ЗАКАЗА ---
@dp.message(Order.name)
async def process_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    await message.answer("Введите ваш номер телефона или ник в Telegram для связи:")
    await state.set_state(Order.contact)

@dp.message(Order.contact)
async def process_contact(message: types.Message, state: FSMContext):
    data = await state.get_data()
    pid = data['pid']
    p = ALL_PRODUCTS[pid]
    user_name = data['name']
    contact = message.text
    
    await database.add_order(message.from_user.id, user_name, pid, p['name'])
    
    admin_msg = f"💰 <b>НОВЫЙ ЗАКАЗ!</b>\nТовар: {p['name']} (ID: {pid})\nЦена: {p['price']}\nФИО: {user_name}\nСвязь: {contact}"
    await bot.send_message(config.ADMIN_ID, admin_msg)
    
    await message.answer("Спасибо! Ваш заказ принят. Менеджер свяжется с вами для уточнения деталей доставки.", reply_markup=get_main_kb())
    await state.clear()

# --- CALLBACKS ---
@dp.callback_query(F.data.startswith("cat:"))
async def show_subcats(callback: types.CallbackQuery):
    cat_code = callback.data.split(":")[1]
    await callback.message.edit_text(f"<b>{CATALOG[cat_code]['name']}</b>\n\nВыберите подкатегорию:", reply_markup=get_subcats_kb(cat_code))

@dp.callback_query(F.data.startswith("sub:"))
async def show_items(callback: types.CallbackQuery):
    _, cat_code, subcat_code = callback.data.split(":")
    subcat_name = CATALOG[cat_code]["subcats"][subcat_code]["name"]
    await callback.message.edit_text(f"<b>{subcat_name}</b>\n\nВыберите товар:", reply_markup=get_items_kb(cat_code, subcat_code))

@dp.callback_query(F.data.startswith("prod:"))
async def show_prod(callback: types.CallbackQuery):
    pid = callback.data.split(":")[1]
    p = ALL_PRODUCTS[pid]
    text = f"<b>{p['name']}</b>\n\n{p['desc']}\n\n💰 Цена: <b>{p['price']}</b>"
    await callback.message.delete()
    await callback.message.answer_photo(photo=p['photo'], caption=text, reply_markup=get_prod_kb(pid))

@dp.callback_query(F.data.startswith("buy:"))
async def buy_item(callback: types.CallbackQuery, state: FSMContext):
    pid = callback.data.split(":")[1]
    await state.update_data(pid=pid)
    await callback.message.answer(f"Оформляем заказ на <b>{ALL_PRODUCTS[pid]['name']}</b>.\nВведите ваше ФИО:", reply_markup=types.ReplyKeyboardRemove())
    await state.set_state(Order.name)
    await callback.answer()

@dp.callback_query(F.data == "back:main")
async def back_main(callback: types.CallbackQuery):
    await callback.message.edit_text("Выберите категорию:", reply_markup=get_cats_kb())

@dp.callback_query(F.data.startswith("back:cat:"))
async def back_cat(callback: types.CallbackQuery):
    cat_code = callback.data.split(":")[2]
    await callback.message.edit_text(f"<b>{CATALOG[cat_code]['name']}</b>\n\nВыберите подкатегорию:", reply_markup=get_subcats_kb(cat_code))

@dp.callback_query(F.data.startswith("back:sub:"))
async def back_sub(callback: types.CallbackQuery):
    _, _, cat_code, subcat_code = callback.data.split(":")
    subcat_name = CATALOG[cat_code]["subcats"][subcat_code]["name"]
    await callback.message.delete()
    await callback.message.answer(f"<b>{subcat_name}</b>\n\nВыберите товар:", reply_markup=get_items_kb(cat_code, subcat_code))

# --- АДМИН-КОМАНДЫ ---
@dp.message(Command("orders"), F.from_user.id == config.ADMIN_ID)
async def view_orders(message: types.Message):
    orders = await database.get_all_orders()
    if not orders:
        await message.answer("Заказов пока нет.")
        return
    text = "📋 <b>Последние 10 заказов:</b>\n\n"
    for o in orders:
        text += f"ID: {o[0]} | {o[4]} | {o[3]} | {o[6]}\n"
    await message.answer(text)

async def main():
    await database.init_db()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
